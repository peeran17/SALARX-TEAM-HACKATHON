from flask import Flask, render_template, jsonify, request
import sqlite3
from datetime import datetime

app = Flask(__name__)

DB = "parking.db"

# -------------------------
# Create Database + Table
# -------------------------
def init_db():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS parking (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        location TEXT,
        slot INTEGER,
        status INTEGER,
        start_time TEXT
    )
    """)

    # Insert default slots if empty
    cur.execute("SELECT COUNT(*) FROM parking")
    if cur.fetchone()[0] == 0:
        locations = ["Block A", "Block B", "Library", "Auditorium"]
        for loc in locations:
            for s in range(1, 7):  # 6 slots per location
                cur.execute(
                    "INSERT INTO parking(location,slot,status,start_time) VALUES(?,?,?,?)",
                    (loc, s, 0, None)
                )

    conn.commit()
    conn.close()

init_db()

# -------------------------
# Home Page
# -------------------------
@app.route("/")
def home():
    locations = ["Block A", "Block B", "Library", "Auditorium"]
    return render_template("index.html", locations=locations)

# -------------------------
# Get Slots of Location
# -------------------------
@app.route("/get_slots/<location>")
def get_slots(location):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("SELECT slot,status,start_time FROM parking WHERE location=?", (location,))
    rows = cur.fetchall()

    now = datetime.now()
    data = []
    free = 0

    for slot, status, start in rows:
        duration = ""
        if status == 1 and start:
            diff = now - datetime.fromisoformat(start)
            duration = f"{diff.seconds//60} min"
        else:
            free += 1

        data.append({
            "slot": slot,
            "status": status,
            "duration": duration
        })

    conn.close()
    return jsonify({"slots": data, "free": free})

# -------------------------
# Toggle Slot (Park / Leave)
# -------------------------
@app.route("/toggle", methods=["POST"])
def toggle():
    location = request.json["location"]
    slot = request.json["slot"]

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("SELECT status FROM parking WHERE location=? AND slot=?", (location, slot))
    current = cur.fetchone()[0]

    if current == 0:
        cur.execute("UPDATE parking SET status=1,start_time=? WHERE location=? AND slot=?",
                    (datetime.now().isoformat(), location, slot))
    else:
        cur.execute("UPDATE parking SET status=0,start_time=NULL WHERE location=? AND slot=?",
                    (location, slot))

    conn.commit()
    conn.close()

    return jsonify({"success": True})

# -------------------------
if __name__ == "__main__":
    app.run(debug=True)